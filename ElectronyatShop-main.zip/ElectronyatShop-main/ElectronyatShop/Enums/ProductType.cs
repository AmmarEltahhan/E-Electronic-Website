﻿namespace ElectronyatShop.Enums;

public enum ProductType
{
    Laptop = 0,
    Mouse = 1,
    Keyboard = 2,
    Headset = 3,
    Monitor = 4,
}