﻿namespace ElectronyatShop.Enums;

public enum OrderStatus
{
	Ordered,
	Shipped,
	OnTheWay,
	Delivered,
	Cancelled
}