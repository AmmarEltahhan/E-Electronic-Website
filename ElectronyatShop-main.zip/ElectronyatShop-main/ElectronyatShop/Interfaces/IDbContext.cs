namespace ElectronyatShop.Interfaces;

interface IDbContext;